from __future__ import annotations

import csv
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import story_workflow
import apply_narration_durations
from assemble_r2v_story import retime_plan_to_authoritative_audio
from apply_narration_durations import generation_duration_for_target
from story_agent import AgentContext, StoryAgent
from story_project import init_project, project_paths, write_manifest
from story_video_synthesizer.align import LineTiming
from story_video_synthesizer.pipeline import SynthesisConfig, _render_video_segments, synthesize_story


class AdaptiveTimingTests(unittest.TestCase):
    def test_r2v_assembly_projects_shot_boundaries_from_authoritative_audio(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            audio = root / "audio.m4a"
            timings = root / "timings.json"
            audio.write_bytes(b"audio")
            timings.write_text("[]", encoding="utf-8")
            plan = {
                "shots": [
                    {"shot_id": "S01", "story_text": "正文一\n正文二"},
                    {"shot_id": "S02", "story_text": "正文三"},
                    {"shot_id": "MORAL", "story_text": "寓意"},
                ]
            }
            rows = [
                {"line": "主持开场", "source_start": 0.0, "source_end": 2.0},
                {"line": "正文一", "source_start": 3.0, "source_end": 4.0},
                {"line": "正文二", "source_start": 4.0, "source_end": 5.0},
                {"line": "正文三", "source_start": 6.0, "source_end": 7.0},
                {"line": "寓意一", "source_start": 8.0, "source_end": 9.0},
            ]
            result = retime_plan_to_authoritative_audio(
                plan,
                rows,
                audio_path=audio,
                audio_duration=10.0,
                timings_path=timings,
            )
            self.assertEqual(result["title_window"], [0.0, 3.0])
            self.assertEqual(
                [(item["source_start"], item["source_end"]) for item in result["shots"]],
                [(3.0, 6.0), (6.0, 8.0), (8.0, 10.0)],
            )
            self.assertEqual(result["shots"][0]["authoritative_line_start"], 2)

    def test_formal_synthesis_rejects_even_alignment_fallback_before_execution(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = SynthesisConfig(
                video_dir=root / "videos",
                script_path=root / "script.txt",
                narration_path=root / "voice.wav",
                music_path=root / "music.mp3",
                output_dir=root / "output",
                project_dir=root,
                alignment_mode="even",
            )
            with self.assertRaisesRegex(ValueError, "even|均分"):
                synthesize_story(config)

    def test_adaptive_seconds_rounds_up_and_clamps_to_provider_bounds(self) -> None:
        kwargs = {
            "duration_mode": "adaptive-seconds",
            "fixed_duration": 10,
            "min_generation_seconds": 1,
            "max_generation_seconds": 15,
        }
        self.assertEqual(generation_duration_for_target(9.83, **kwargs), 10)
        self.assertEqual(generation_duration_for_target(8.09, **kwargs), 9)
        self.assertEqual(generation_duration_for_target(4.17, **kwargs), 5)
        self.assertEqual(generation_duration_for_target(0.01, **kwargs), 1)
        self.assertEqual(generation_duration_for_target(99.0, **kwargs), 15)

    def test_discrete_provider_seconds_choose_nearest_and_fit_later(self) -> None:
        kwargs = {
            "duration_mode": "adaptive-seconds",
            "min_generation_seconds": 6,
            "max_generation_seconds": 10,
            "generation_duration_choices": (6, 10),
        }
        self.assertEqual(generation_duration_for_target(6.1, **kwargs), 6)
        self.assertEqual(generation_duration_for_target(7.99, **kwargs), 6)
        self.assertEqual(generation_duration_for_target(8.0, **kwargs), 10)
        self.assertEqual(generation_duration_for_target(12.5, **kwargs), 10)

    def test_compositor_uses_the_complete_clip_with_uniform_speed_change(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "provider_10s.mp4"
            source.write_bytes(b"fixture")
            config = SynthesisConfig(
                video_dir=root,
                script_path=root / "script.txt",
                narration_path=root / "voice.wav",
                music_path=root / "music.mp3",
                output_dir=root,
            )
            timing = LineTiming(1, "测试", 0.0, 6.5, 6.5, 0.0, 6.5)
            with patch(
                "story_video_synthesizer.pipeline.probe_duration", return_value=10.0
            ), patch("story_video_synthesizer.pipeline.run_command") as run:
                _render_video_segments([source], [timing], [6.5], root / "work", config)
            command = run.call_args.args[0]
            video_filter = command[command.index("-vf") + 1]
            self.assertIn("trim=0:10.000", video_filter)
            self.assertIn("setpts=0.65000000*(PTS-STARTPTS)", video_filter)

    def test_fixed_mode_keeps_existing_generation_duration(self) -> None:
        self.assertEqual(
            generation_duration_for_target(
                4.17,
                duration_mode="fixed",
                fixed_duration=10,
                min_generation_seconds=1,
                max_generation_seconds=15,
            ),
            10.0,
        )

    def test_adaptive_rows_store_truthful_seconds_and_compatibility_frames(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            jobs = root / "jobs.csv"
            jobs.write_text(
                "scene,image_filename,story_text,prompt,target_video_filename,status\n"
                "1,01.png,甲,甲,01.mp4,todo\n"
                "2,02.png,乙,乙,02.mp4,todo\n"
                "3,03.png,丙,丙,03.mp4,todo\n",
                encoding="utf-8-sig",
            )
            narration = root / "narration.m4a"
            narration.write_bytes(b"audio")
            timings = [
                LineTiming(1, "甲", 0.0, 9.68, 9.68, 0.0, 9.68),
                LineTiming(2, "乙", 9.68, 17.62, 7.94, 9.68, 17.62),
                LineTiming(3, "丙", 17.62, 21.64, 4.02, 17.62, 21.64),
            ]
            argv = [
                "apply_narration_durations.py",
                "--jobs-csv",
                str(jobs),
                "--narration",
                str(narration),
                "--alignment-mode",
                "even",
                "--duration-mode",
                "adaptive-seconds",
                "--min-generation-seconds",
                "1",
                "--max-generation-seconds",
                "15",
            ]
            with patch.object(sys, "argv", argv), patch.object(
                apply_narration_durations, "align_script_to_narration", return_value=timings
            ):
                apply_narration_durations.main()
            with jobs.open(encoding="utf-8-sig", newline="") as file:
                rows = list(csv.DictReader(file))
            self.assertEqual([row["generation_duration"] for row in rows], ["10", "9", "5"])
            self.assertEqual([row["duration"] for row in rows], ["10", "9", "5"])
            self.assertEqual([row["effective_duration"] for row in rows], ["10.000", "9.000", "5.000"])
            self.assertEqual([row["frames"] for row in rows], ["240", "216", "120"])
            self.assertTrue(all(row["duration_mode"] == "adaptive-seconds" for row in rows))

    def test_workflow_forwards_adaptive_mode_and_bounds(self) -> None:
        argv = [
            "story_workflow.py",
            "timing",
            "--jobs-csv",
            "jobs.csv",
            "--narration",
            "narration.m4a",
            "--duration-mode",
            "adaptive-seconds",
            "--min-generation-seconds",
            "1",
            "--max-generation-seconds",
            "15",
        ]
        with patch.object(sys, "argv", argv), patch.object(story_workflow, "run_script") as runner:
            story_workflow.main()
        command = list(runner.call_args.args)
        self.assertEqual(command[0], "apply_narration_durations.py")
        self.assertIn("--duration-mode", command)
        self.assertEqual(command[command.index("--duration-mode") + 1], "adaptive-seconds")
        self.assertEqual(command[command.index("--min-generation-seconds") + 1], "1.0")
        self.assertEqual(command[command.index("--max-generation-seconds") + 1], "15.0")

    def test_has_timing_rejects_prepare_placeholder_duration(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            project = Path(directory) / "故事剪辑：时长闸门"
            manifest = init_project(project, story_name="时长闸门", slug="timing-gate")
            jobs = project_paths(project).video_jobs / "timing-gate_image_video_jobs.csv"
            jobs.parent.mkdir(parents=True, exist_ok=True)
            jobs.write_text(
                "scene,target_video_filename,duration,frames,status\n1,01.mp4,10,240,todo\n",
                encoding="utf-8-sig",
            )
            manifest["outputs"]["jobs_csv"] = str(jobs)
            write_manifest(project_paths(project), manifest)
            context = AgentContext(
                project_dir=project,
                inbox=None,
                story_name="时长闸门",
                slug="timing-gate",
                execute=False,
                update_latest_episode=False,
                codex_mode="handoff",
                codex_model="",
                codex_sandbox="read-only",
                codex_approval="never",
                codex_path="codex",
                codex_timeout=30,
            )
            agent = StoryAgent(context, read_only=True)
            self.assertFalse(agent._has_timing(manifest))

    def test_has_timing_accepts_real_row_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            project = Path(directory) / "故事剪辑：时长元数据"
            manifest = init_project(project, story_name="时长元数据", slug="timing-metadata")
            jobs = project_paths(project).video_jobs / "timing-metadata_image_video_jobs.csv"
            jobs.parent.mkdir(parents=True, exist_ok=True)
            jobs.write_text(
                "scene,target_video_filename,duration,frames,status,target_duration,narration_start,narration_end,generation_duration,duration_mode\n"
                "1,01.mp4,5,120,todo,4.17,0.000,4.020,5,adaptive-seconds\n",
                encoding="utf-8-sig",
            )
            manifest["outputs"]["jobs_csv"] = str(jobs)
            write_manifest(project_paths(project), manifest)
            context = AgentContext(
                project_dir=project,
                inbox=None,
                story_name="时长元数据",
                slug="timing-metadata",
                execute=False,
                update_latest_episode=False,
                codex_mode="handoff",
                codex_model="",
                codex_sandbox="read-only",
                codex_approval="never",
                codex_path="codex",
                codex_timeout=30,
            )
            self.assertTrue(StoryAgent(context, read_only=True)._has_timing(manifest))

    def test_stage_timing_selects_adaptive_for_current_grok_capabilities(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            project = Path(directory) / "故事剪辑：Grok 时长"
            manifest = init_project(project, story_name="Grok 时长", slug="grok-timing")
            paths = project_paths(project)
            narration = paths.inputs / "narration.m4a"
            narration.write_bytes(b"audio")
            jobs = paths.video_jobs / "grok-timing_image_video_jobs.csv"
            jobs.parent.mkdir(parents=True, exist_ok=True)
            jobs.write_text("scene,target_video_filename,status\n1,01.mp4,todo\n", encoding="utf-8-sig")
            manifest["inputs"]["narration"] = str(narration)
            manifest["outputs"]["jobs_csv"] = str(jobs)
            write_manifest(paths, manifest)
            context = AgentContext(
                project_dir=project,
                inbox=None,
                story_name="Grok 时长",
                slug="grok-timing",
                execute=False,
                update_latest_episode=False,
                codex_mode="handoff",
                codex_model="",
                codex_sandbox="read-only",
                codex_approval="never",
                codex_path="codex",
                codex_timeout=30,
            )
            agent = StoryAgent(context, read_only=True)
            config = {
                "video_api": {
                    "provider": "configured_provider",
                    "adapters": {
                        "configured_provider": {
                            "runner": "run_image_video_jobs.py",
                            "model": "grok-video-1.0",
                            "min_seconds": 6,
                            "max_seconds": 10,
                            "duration_choices": [6, 10],
                        }
                    },
                }
            }
            with patch("story_agent.load_config", return_value=config), patch.object(
                agent, "_workflow", return_value=type("Result", (), {"status": "done", "message": "ok", "handoff": None})()
            ) as workflow:
                agent._stage_timing(manifest)
            command = list(workflow.call_args.args[0])
            self.assertIn("--duration-mode", command)
            self.assertEqual(command[command.index("--duration-mode") + 1], "adaptive-seconds")
            self.assertEqual(command[command.index("--min-generation-seconds") + 1], "6")
            self.assertEqual(command[command.index("--max-generation-seconds") + 1], "10")
            self.assertEqual(command[command.index("--generation-duration-choices") + 1], "6,10")


if __name__ == "__main__":
    unittest.main()
